import os
from sqlalchemy import create_engine


def lambda_handler(event, context):
    var1 = os.environ.get("var1")
    var2 = os.environ.get("var2")

    print('Entrou!!!!!!', var1, var2)

    db = create_engine(
        'postgresql+pg8000://root:hopes030411@gymbraininstance.c1pkp7hr6szo.us-east-1.rds.amazonaws.com:5432/gymbrain')
    results = db.execute("SELECT * FROM public.core_clickon")
    for r in results:
        if r.points_clickon == None:
            print(r.email)
